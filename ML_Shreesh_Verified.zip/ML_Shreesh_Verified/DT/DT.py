#import packages
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier

dataset=pd.read_csv("tree1.csv")

x = dataset.iloc[:,:-1]
y = dataset.iloc[:,-1]


le = LabelEncoder()

x = x.apply(le.fit_transform)

print(x)


classifier=DecisionTreeClassifier()

classifier.fit(x.iloc[:,1:5],y)


y_pred = classifier.predict([[1,1,0,0]])

print(y_pred)
















